def check_password_strength(pwd):
    # Password should be 8+ characters, include a number, a symbol, and no spaces
    return (
        len(pwd) >= 8 
        and any(c.isdigit() for c in pwd) 
        and any(not c.isalnum() for c in pwd) 
        and " " not in pwd  # Check for no spaces
    )

def cipher(text, shift, decrypt=False):
    if decrypt:
        shift = -shift  # Reverse shift for decryption
    result = ""
    for i in text:
        if i.isalpha():
            # Shift character within the alphabet, considering case
            shifted = chr((ord(i.lower()) - 97 + shift) % 26 + 97)
            result += shifted.upper() if i.isupper() else shifted
        else:
            result += i  # Keep non-alphabet characters unchanged
    return result

# Ask for name and password setup
name = input("Enter your name: ")
while True:
    pwd = input("Set a password: ")
    if check_password_strength(pwd):
        print("Password set successfully!")
        break
    else:
        print("Password is weak. Ensure it has no spaces, at least 8 characters, a number, and a symbol.")

# Verify password
while True:
    verify_pwd = input("Enter your password to proceed: ")
    if verify_pwd == pwd:
        print("Welcome,", name, "!")
        break
    else:
        print("Incorrect password. Please try again.")

# Main menu for encryption or decryption
while True:
    print("\nChoose an option:")
    print("1. Encrypt a message")
    print("2. Decrypt a message")
    print("3. Exit")
    choice = input("Enter choice (1/2/3): ")

    if choice == "1" or choice == "2":
        msg = input("Enter the message: ")
        shift = int(input("Enter the number of shifts: "))
        
        if choice == "1":
            encrypted = cipher(msg, shift)
            print("Encrypted Message:", encrypted)
            break
        else:
            decrypted = cipher(msg, shift, decrypt=True)
            print("Decrypted Message:", decrypted)
            break
    elif choice == "3":
        print("Thank you kindly.")
        break
    else:
        print("Invalid choice. Please choose 1, 2, or 3.")
        
        
print("All copyrights reserved.")
