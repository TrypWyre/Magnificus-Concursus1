def caesar_encrypt(text, shift):
    encrypted = ""
    for char in text:
        if char.isalpha():
            shifted = chr((ord(char.lower()) - 97 + shift) % 26 + 97)
            encrypted += shifted.upper() if char.isupper() else shifted
        else:
            encrypted += char  # Leave non-alphabet characters as they are
    return encrypted



def caesar_decrypt(text, shift):
    return caesar_encrypt(text, -shift)  # Decryption is reverse shift



# Example usage
message = input("Enter message: ")
shift = 5
encrypted_message = caesar_encrypt(message, shift)
decrypted_message = caesar_decrypt(encrypted_message, shift)
print(f"Encrypted: {encrypted_message}")
print(f"Decrypted: {decrypted_message}")
