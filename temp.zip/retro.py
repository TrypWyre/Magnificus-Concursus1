x = int(input())
y = int(input())
z = int(input())
n = int(input())
main_list=[]
    
for i in range(x):
    l1=[]
    l1.append(i)
    for j in range(y):
        l1.append(j)
        for k in range(z):
            l1.append(k)